from flask import Flask, render_template

app = Flask(__name__)

#utilizei esse comando para conseguir fazer as alterações sem o cache atrapalhar
app.config['SEND_FILE_MAX_AGE_DEFAULT']=0

@app.route("/")
def homepage():
    return render_template("index.html")

if __name__ == "__main__":
 app.run()