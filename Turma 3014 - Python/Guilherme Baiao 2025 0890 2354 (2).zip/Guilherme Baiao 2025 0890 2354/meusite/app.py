from flask import Flask, render_template

app = Flask(__name__)

@app.route("/")
def home():
    aluno =" ola , aluno"
    imagem = "img/download.jpg"
    return render_template("index.html", aluno=aluno,imagem=imagem )
       

if __name__ == "__main__":
    app.run(debug=True)